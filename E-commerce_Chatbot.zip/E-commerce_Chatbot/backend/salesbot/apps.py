from django.apps import AppConfig


class SalesbotConfig(AppConfig):
    name = 'salesbot'
