from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField()
    category = models.CharField(max_length=100)
    image = models.URLField(blank=True, null=True)
    rating = models.FloatField(default=4.0)

    def __str__(self):
        return self.name

class ChatLog(models.Model):
    user_message = models.TextField()
    bot_response = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.timestamp} - {self.user_message[:30]}'
