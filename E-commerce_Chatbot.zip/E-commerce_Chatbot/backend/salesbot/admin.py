from django.contrib import admin
from .models import Product, ChatLog

admin.site.register(Product)
admin.site.register(ChatLog)
