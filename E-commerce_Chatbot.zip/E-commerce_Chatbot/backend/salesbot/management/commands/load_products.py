import csv
from django.core.management.base import BaseCommand
from salesbot.models import Product

class Command(BaseCommand):
    help = 'Load mock product data from CSV'

    def handle(self, *args, **kwargs):
        with open('mock_products.csv', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                Product.objects.get_or_create(
                    name=row['name'],
                    price=float(row['price']),
                    category=row['category'],
                    image=row.get('image', ''),
                    rating=float(row.get('rating', 4.0)),
                )
        self.stdout.write(self.style.SUCCESS('Products loaded successfully.'))
