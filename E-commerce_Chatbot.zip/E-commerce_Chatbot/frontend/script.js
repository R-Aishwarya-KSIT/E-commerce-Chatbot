const chatWindow = document.getElementById('chat-window');
const userInput = document.getElementById('user-input');
const priceSlider = document.getElementById('priceFilter');
const priceVal = document.getElementById('priceVal');
const categoryFilter = document.getElementById('categoryFilter');
const productsSection = document.getElementById('products');

// Update price label in real-time
priceSlider.addEventListener('input', () => {
  priceVal.textContent = `₹${priceSlider.value}`;
  fetchProducts();
});

categoryFilter.addEventListener('change', fetchProducts);

// Sends message and simulates bot response
function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  appendMessage(message, 'user');
  userInput.value = '';

  const botResponse = `Searching for: ${message}`;

  setTimeout(() => {
    appendMessage(botResponse, 'bot');
    fetchProducts(message);

    // Save to ChatLog API
    fetch('http://127.0.0.1:8000/api/chatlog/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_message: message,
        bot_response: botResponse
      })
    }).catch(error => console.error("Chat log save failed:", error));
  }, 500);
}

function resetChat() {
  chatWindow.innerHTML = '';
  userInput.value = '';
  productsSection.innerHTML = '';
}

function appendMessage(message, sender) {
  const msgDiv = document.createElement('div');
  msgDiv.className = sender;
  msgDiv.textContent = `${sender === 'user' ? 'You' : 'Bot'}: ${message}`;
  chatWindow.appendChild(msgDiv);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

// Fetch and display products from backend
function fetchProducts(searchQuery = '') {
  const category = categoryFilter.value;
  const maxPrice = priceSlider.value;

  let url = `http://127.0.0.1:8000/api/products/?price_lte=${maxPrice}`;
  if (category) url += `&category=${category}`;
  if (searchQuery) url += `&search=${searchQuery}`;

  console.log("📡 Fetching from:", url);

  fetch(url)
    .then(res => res.json())
    .then(data => {
      console.log("🛒 Products fetched:", data);
      displayProducts(data);
    })
    .catch(err => console.error("❌ API Error:", err));
}

function displayProducts(products) {
  productsSection.innerHTML = '';

  if (!Array.isArray(products) || products.length === 0) {
    productsSection.innerHTML = '<p style="color:red;">⚠️ No matching products found.</p>';
    console.warn("⚠️ No products matched the filter.");
    return;
  }

  products.forEach(product => {
    const imageUrl = product.image && product.image.startsWith('http')
      ? product.image
      : `https://via.placeholder.com/250x180?text=${encodeURIComponent(product.name)}`;

    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${imageUrl}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>₹${product.price.toFixed(2)} - ${product.category}</p>
      <p>⭐ ${'★'.repeat(product.rating || 4)}</p>
      <button>🛒 Add to Cart</button>
    `;
    productsSection.appendChild(card);
  });
}

// Load all products on initial page load
document.addEventListener('DOMContentLoaded', () => {
  fetchProducts();
});